package dcs.gridscheduler.gui;

import javax.swing.JPanel;

/**
 * Panel that reports information about components in the VGS. 
 * 
 * @author Niels Brouwers
 *
 */
public abstract class StatusPanel extends JPanel  {

	private static final long serialVersionUID = 4063096546482156186L;

}
