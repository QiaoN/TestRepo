package dcs.gridscheduler.simulation;

import java.rmi.RemoteException;
import java.util.logging.Level;

import com.sun.media.jfxmedia.logging.Logger;

import dcs.gridscheduler.model.Client;
import dcs.gridscheduler.model.Job;
import dcs.gridscheduler.model.ServerURL;

public class ClientSimulation {

	public static void main(String[] args) {
		
		//get id from console id = 110, 120 or 130
		int id = (args.length < 1)? 0 :Integer.valueOf(args[0]);
		
		// ServerList
		ServerURL[] serverURLList = new ServerURL[]{new ServerURL(101,"//54.93.96.147:1099/gridscheduler"), new ServerURL(102,"//54.93.110.161:1099/gridscheduler"),new ServerURL(103,"//52.59.249.167:1099/gridscheduler"),new ServerURL(104,"//54.93.59.172:1099/gridscheduler")};

		Client aClient = new Client(id,"Client."+Integer.toString(id));
		boolean connect = false;
		int loop = 0;
		while (true){
		connect = aClient.connectToServer(serverURLList);
		// connected --> break the while loop
		if (connect ==true) break;
		else loop++;
		// the number of loop = 3 --> break the while loop
		if (loop == 3) break;
		}
		if (loop == 3) System.out.println("Cannot connect to server."); 
		
		// Send job to server. A job with id = 1234, duration = 1000 ms
		//Job aNewJob = new Job(1000,1234);
		//if (connect == true) aClient.submitAJobToServer(aNewJob);
		
		// Send a thousand of workloads to test...
		for (int i= 0; i<20; i++){
			Job bNewJob=null;
			try {
				//int duration = new Random().nextInt((19 - 11 + 1) + 11);
				//int duratoinTime = duration*1000;
				int durationTime = 15000;
				// job id = 1100000 - enough for x*10000 jobs per client
				bNewJob = new Job(durationTime,id*1000+i);
			} catch (RemoteException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if (connect == true) aClient.submitAJobToServer(bNewJob);
			try {
				Thread.sleep(5);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
